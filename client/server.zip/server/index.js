const express = require("express");
const cors = require("cors");
require("dotenv").config();

const connectDB = require("./config/db");
const customerRoutes = require("./routes/customerRoutes");

const app = express();

connectDB();

app.use(cors());
app.use(express.json());

// Test Route
app.get("/test", (req, res) => {
  res.send("Test Working");
});

// Customer Routes
app.use("/api/customers", customerRoutes);

// Home Route
app.get("/", (req, res) => {
  res.send("Backend Running");
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});