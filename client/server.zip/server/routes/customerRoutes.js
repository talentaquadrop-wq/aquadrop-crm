const express = require("express");
const router = express.Router();

const {
  addCustomer,
  getCustomers,
} = require("../controllers/customerController");

// GET All Customers
router.get("/", getCustomers);

// POST Add Customer
router.post("/", addCustomer);

module.exports = router;