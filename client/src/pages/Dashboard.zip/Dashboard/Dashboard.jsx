import React from "react";
import "./Dashboard.css";

import WelcomeSection from "./WelcomeSection";
import StatCard from "./StatCard";
import Charts from "./Charts";
import QuickActions from "./QuickActions";
import RecentActivities from "./RecentActivities";
import TodayInstallations from "./TodayInstallations";
import LowStock from "./LowStock";
import RecentCustomers from "./RecentCustomers";
import RevenueCard from "./RevenueCard";

import {
  FaUsers,
  FaUserFriends,
  FaTools,
  FaClock,
  FaCheckCircle,
  FaRupeeSign,
} from "react-icons/fa";

const Dashboard = () => {
  return (
    <main className="dashboard-content">

      {/* PAGE HEADER */}
      <div className="dashboard-page-header">
        <div>
          <h1>Dashboard</h1>
          <p>Overview of your Aqua Drop business operations.</p>
        </div>

        <div className="dashboard-date">
          Today
        </div>
      </div>

      {/* WELCOME SECTION */}
      <WelcomeSection />

      {/* STATISTICS */}
      <section className="stats-grid">

        <StatCard
          title="Total Leads"
          value="1248"
          growth="12%"
          icon={<FaUsers />}
          color="#2563EB"
        />

        <StatCard
          title="Customers"
          value="856"
          growth="8%"
          icon={<FaUserFriends />}
          color="#059669"
        />

        <StatCard
          title="Installations"
          value="512"
          growth="5%"
          icon={<FaTools />}
          color="#7C3AED"
        />

        <StatCard
          title="Pending Services"
          value="78"
          growth="3%"
          icon={<FaClock />}
          color="#D97706"
        />

        <StatCard
          title="Completed Services"
          value="324"
          growth="15%"
          icon={<FaCheckCircle />}
          color="#16A34A"
        />

        <StatCard
          title="Revenue"
          value="₹8.92L"
          growth="20%"
          icon={<FaRupeeSign />}
          color="#DC2626"
        />

      </section>

      {/* ANALYTICS */}
      <section className="dashboard-section">

        <div className="section-heading">
          <div>
            <h2>Business Overview</h2>
            <p>Sales and business performance summary</p>
          </div>
        </div>

        <div className="dashboard-charts">
          <Charts />
        </div>

      </section>

      {/* QUICK ACTIONS */}
      <section className="dashboard-section">

        <div className="section-heading">
          <div>
            <h2>Quick Actions</h2>
            <p>Frequently used actions</p>
          </div>
        </div>

        <QuickActions />

      </section>

      {/* OPERATION OVERVIEW */}
      <section className="dashboard-section">

        <div className="section-heading">
          <div>
            <h2>Today's Operations</h2>
            <p>Activities that need your attention</p>
          </div>
        </div>

        <div className="bottom-grid">

          <div className="dashboard-panel">
            <RecentActivities />
          </div>

          <div className="dashboard-panel">
            <TodayInstallations />
          </div>

          <div className="dashboard-panel">
            <LowStock />
          </div>

        </div>

      </section>

      {/* CUSTOMERS + REVENUE */}
      <section className="dashboard-lower-grid">

        <div className="dashboard-panel">
          <RecentCustomers />
        </div>

        <div className="dashboard-panel">
          <RevenueCard />
        </div>

      </section>

    </main>
  );
};

export default Dashboard;