import React from "react";
import {
  FaBoxOpen,
  FaExclamationTriangle,
} from "react-icons/fa";

import "./LowStock.css";

const LowStock = () => {
  const products = [
    {
      name: "Aqua Drop Water Softener",
      stock: 5,
      unit: "Units",
      status: "Low Stock",
    },
    {
      name: "Aqua Drop Premium",
      stock: 3,
      unit: "Units",
      status: "Critical",
    },
    {
      name: "Replacement Filter",
      stock: 12,
      unit: "Units",
      status: "Low Stock",
    },
    {
      name: "Installation Kit",
      stock: 7,
      unit: "Units",
      status: "Low Stock",
    },
  ];

  return (
    <div className="low-stock">

      <div className="low-stock-header">

        <div>
          <h3>Low Stock</h3>
          <p>Products that need attention</p>
        </div>

        <div className="stock-warning">
          <FaExclamationTriangle />
        </div>

      </div>

      <div className="stock-list">

        {products.map((product, index) => (
          <div
            className="stock-row"
            key={index}
          >

            <div className="stock-product">

              <div className="stock-icon">
                <FaBoxOpen />
              </div>

              <div className="stock-details">

                <h4>
                  {product.name}
                </h4>

                <p>
                  Available: {product.stock} {product.unit}
                </p>

              </div>

            </div>

            <span
              className={`stock-status ${
                product.status === "Critical"
                  ? "critical"
                  : "low-stock-status"
              }`}
            >
              {product.status}
            </span>

          </div>
        ))}

      </div>

      <button className="view-products-btn">
        View Products
      </button>

    </div>
  );
};

export default LowStock;