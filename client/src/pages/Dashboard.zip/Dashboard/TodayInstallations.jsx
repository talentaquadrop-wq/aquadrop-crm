import React from "react";
import { FaTools, FaClock } from "react-icons/fa";

import "./TodayInstallations.css";

const TodayInstallations = () => {
  const installations = [
    {
      customer: "Ramesh Kumar",
      product: "Aqua Drop Water Softener",
      time: "10:00 AM",
      status: "Scheduled",
    },
    {
      customer: "Suresh Reddy",
      product: "Aqua Drop Premium",
      time: "12:30 PM",
      status: "Scheduled",
    },
    {
      customer: "Mahesh Kumar",
      product: "Aqua Drop Water Softener",
      time: "03:00 PM",
      status: "Pending",
    },
    {
      customer: "Kiran Kumar",
      product: "Aqua Drop Premium",
      time: "05:30 PM",
      status: "Pending",
    },
  ];

  return (
    <div className="today-installations">

      <div className="installations-card-header">
        <div>
          <h3>Today's Installations</h3>
          <p>Scheduled installation activities</p>
        </div>

        <span className="installation-count">
          {installations.length}
        </span>
      </div>

      <div className="installations-list">

        {installations.map((item, index) => (
          <div
            className="today-installation-row"
            key={index}
          >

            <div className="installation-main">

              <div className="installation-icon">
                <FaTools />
              </div>

              <div className="installation-details">

                <h4>{item.customer}</h4>

                <p>{item.product}</p>

              </div>

            </div>


            <div className="installation-right">

              <div className="installation-time">
                <FaClock />
                <span>{item.time}</span>
              </div>

              <span
                className={`installation-status ${item.status.toLowerCase()}`}
              >
                {item.status}
              </span>

            </div>

          </div>
        ))}

      </div>

    </div>
  );
};

export default TodayInstallations;