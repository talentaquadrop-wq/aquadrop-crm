const Lead = require("../models/Lead");
const Customer = require("../models/Customer");
const Installation = require("../models/Installation");
const Service = require("../models/Service");
const Product = require("../models/Product");

console.log("🔥 NEW DASHBOARD CONTROLLER LOADED");

// ====================================
// Dashboard Statistics
// ====================================

const getDashboardStats = async (req, res) => {

  console.log("🔥 getDashboardStats RUNNING");

  try {

    // Total Counts
    const totalLeads = await Lead.countDocuments();

    const totalCustomers = await Customer.countDocuments();

    const totalInstallations = await Installation.countDocuments();

    const pendingServices = await Service.countDocuments({
      status: "Pending",
    });

    const completedServices = await Service.countDocuments({
      status: "Completed",
    });

    const totalProducts = await Product.countDocuments();
    // Low Stock Products
const lowStockProducts = await Product.find({
  quantity: { $lte: 5 },
})
.sort({ quantity: 1 })
.limit(5);

    // Today's Date
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Today's Leads
    const todayLeads = await Lead.countDocuments({
      createdAt: { $gte: today },
    });

    // Today's Customers
    const todayCustomers = await Customer.countDocuments({
      createdAt: { $gte: today },
    });

    // Recent Leads
    const recentLeads = await Lead.find()
      .sort({ createdAt: -1 })
      .limit(5);

    // Recent Customers
    const recentCustomers = await Customer.find()
      .sort({ createdAt: -1 })
      .limit(5);
      // Recent Installations
const recentInstallations = await Installation.find()
  .sort({ createdAt: -1 })
  .limit(5);

// Recent Services
const recentServices = await Service.find()
  .sort({ createdAt: -1 })
  .limit(5);

    console.log("✅ Dashboard Response:", {
  totalLeads,
  totalCustomers,
  totalInstallations,
  pendingServices,
  completedServices,
  totalProducts,
  todayLeads,
  todayCustomers,
  recentLeads,
  recentCustomers,
  recentInstallations,
  recentServices,
  lowStockProducts,

});
console.log("LOW STOCK =>", lowStockProducts);
res.status(200).json({
  success: true,
  data: {
    totalLeads,
    totalCustomers,
    totalInstallations,
    pendingServices,
    completedServices,
    totalProducts,
    todayLeads,
    todayCustomers,
    recentLeads,
    recentCustomers,
    recentInstallations,
    recentServices,
    lowStockProducts,
  },
});
  } catch (error) {

    console.error("❌ Dashboard Error:", error);

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }

};

module.exports = {
  getDashboardStats,
};