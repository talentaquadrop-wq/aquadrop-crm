const Lead = require("../models/Lead");
const Customer = require("../models/Customer");

// ==============================
// Get All Leads
// ==============================
exports.getLeads = async (req, res) => {
  try {
    const leads = await Lead.find().sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: leads.length,
      data: leads,
    });
  } catch (error) {
    console.error("Get Leads Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch leads",
    });
  }
};
// ==============================
// Get Lead By ID
// ==============================
exports.getLeadById = async (req, res) => {
  try {
    const { id } = req.params;

    const lead = await Lead.findById(id);

    if (!lead) {
      return res.status(404).json({
        success: false,
        message: "Lead not found",
      });
    }

    res.status(200).json({
      success: true,
      data: lead,
    });
  } catch (error) {
    console.error("Get Lead Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch lead",
    });
  }
};
// ==============================
// Create New Lead
// ==============================
exports.createLead = async (req, res) => {
  try {
    const {
      name,
      phone,
      alternatePhone,
      email,
      address,
      city,
      pincode,
      tds,
      waterSource,
      familyMembers,
      source,
      product,
      budget,
      status,
      priority,
      assignedTo,
      assignedTelecaller,
      assignedAgent,
      followUpDate,
      lastFollowUp,
      siteVisitRequired,
      remarks,
    } = req.body;

    // Required Validation
    if (!name || !phone) {
      return res.status(400).json({
        success: false,
        message: "Name and Phone are required.",
      });
    }

    // Duplicate Phone Check
    const existingLead = await Lead.findOne({ phone });

    if (existingLead) {
      return res.status(400).json({
        success: false,
        message: "Lead with this phone number already exists.",
      });
    }

    // Create Lead
    const lead = await Lead.create({
      name,
      phone,
      alternatePhone,
      email,
      address,
      city,
      pincode,
      tds,
      waterSource,
      familyMembers,
      source,
      product,
      budget,
      status,
      priority,
      assignedTo,
      assignedTelecaller,
      assignedAgent,
      followUpDate,
      lastFollowUp,
      siteVisitRequired,
      remarks,
    });

    res.status(201).json({
      success: true,
      message: "Lead created successfully.",
      data: lead,
    });
  } catch (error) {
    console.error("Create Lead Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to create lead.",
    });
  }
};

// ==============================
// Update Lead
// ==============================
exports.updateLead = async (req, res) => {
  try {
    const { id } = req.params;

    // Check if lead exists
    const lead = await Lead.findById(id);

    if (!lead) {
      return res.status(404).json({
        success: false,
        message: "Lead not found.",
      });
    }

    // Duplicate phone validation
    if (req.body.phone) {
      const existingLead = await Lead.findOne({
        phone: req.body.phone,
        _id: { $ne: id },
      });

      if (existingLead) {
        return res.status(400).json({
          success: false,
          message: "Another lead already exists with this phone number.",
        });
      }
    }

    // Update Lead
    const updatedLead = await Lead.findByIdAndUpdate(
      id,
      req.body,
      {
        new: true,
        runValidators: true,
      }
    );

    res.status(200).json({
      success: true,
      message: "Lead updated successfully.",
      data: updatedLead,
    });

  } catch (error) {
    console.error("Update Lead Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to update lead.",
    });
  }
};
// ==============================
// Delete Lead
// ==============================
exports.deleteLead = async (req, res) => {
  try {
    const { id } = req.params;

    const lead = await Lead.findById(id);

    if (!lead) {
      return res.status(404).json({
        success: false,
        message: "Lead not found.",
      });
    }

    await Lead.findByIdAndDelete(id);

    res.status(200).json({
      success: true,
      message: "Lead deleted successfully.",
    });

  } catch (error) {
    console.error("Delete Lead Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to delete lead.",
    });
  }
};
exports.convertLeadToCustomer = async (req, res) => {
  try {
    const { id } = req.params;

    const lead = await Lead.findById(id);

    if (!lead) {
      return res.status(404).json({
        success: false,
        message: "Lead not found.",
      });
    }

    if (lead.isConverted) {
      return res.status(400).json({
        success: false,
        message: "Lead already converted.",
      });
    }

    const customer = await Customer.create({
      name: lead.name,
      phone: lead.phone,
      email: lead.email,
      address: lead.address,
      status: "Active",
    });

    lead.isConverted = true;
    lead.convertedCustomer = customer._id;
    lead.convertedAt = new Date();

    await lead.save();

    res.status(200).json({
      success: true,
      message: "Lead converted successfully.",
      customer,
    });

  } catch (error) {
    console.error("Convert Lead Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to convert lead.",
    });
  }
};